#ifndef MENU_H
#define MENU_H

void print_menu(void);
int *choose(int* n, int c, int * mat, int *dir, int *rot);


#endif // !MENU_H
